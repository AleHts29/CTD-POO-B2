public interface TamagochiState {

    public TamagochiState comer();
    public TamagochiState beber();
    public TamagochiState recibirMimos();

}
