public class Cine {
    private String direccion;
    private Integer cantEspactaculos;

}
