public interface Comparable2 {
    public Integer comparable (Largometraje o);
}
